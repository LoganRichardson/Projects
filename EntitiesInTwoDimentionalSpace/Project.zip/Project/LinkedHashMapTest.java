/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project;

import java.awt.List;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;

/**
 *
 * @author Logan
 */
public class LinkedHashMapTest {

    public static void main(String[] args) {
        LinkedHashMap<Integer, Integer> test = new LinkedHashMap();
        HashMap<Double, Double> hm = new HashMap<Double, Double>();
        LinkedList<LinkedList<Integer>> d = new LinkedList<LinkedList<Integer>>();
       // List<List<List<Integer>>> soduko = new ArrayList<>();
        for (int i = 0; i < 10; i++) {
            for (int j = 0; j < 10; j++) {
              

            }
            System.out.println();
        }

    }
}
