package project;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.Random;

public class Project {

    public static int positionX;
    public static int positionY;
    public static int[] radius;
    public static int[] entityX;
    public static int[] entityY;
    public static int[] mass;
    public static int[] velocityX;
    public static int[] velocityY;
    public static int[] distance;
    public static int[] acceleration;
    public static int[] gravitation;
    public static int[] entityDifference;
    public static int time = 1;
    public static int width;
    public static int height;
    public static int temp = 0;
    public static int G = 1;
    public static int x1;
    public static int x2;
    public static int y1;
    public static int y2;
    public static int pLeft;
    public static int pRight;
    public static int pBottom;
    public static int pTop;
    public static int moveUI_1;
    public static int moveUI_2;
    public static int[][] testarray;

    public static void main(String[] args) {
        int value = 1;
        width = 800;
        height = 800;
        pLeft = 200;
        pRight = width / 2;
        pBottom = 200;
        pTop = height / 2;
        ArrayList[][] bigArray = new ArrayList[width][height];
        menuMethod(width, height, 0, value, bigArray);
    }//End of main method

    public static int menuMethod(int width, int height, int circles, int value, ArrayList[][] bigArray) {
        LinkedList<Integer> LL1 = new LinkedList<Integer>();
        int size = width * height;
        for (int i = 0; i < bigArray.length; i++) {
            for (int j = 0; j < bigArray.length; j++) {
                bigArray[i][j] = new ArrayList();
            }
        }
        ImageConstruction cons = new ImageConstruction(width, height, pLeft, pRight, pBottom, pTop, 1);
        KeyboardInputClass numbervalue = new KeyboardInputClass();
        if (value == 1) {
            cons.displaySetup();
            cons.setPixelValues();
            menuContents(cons, bigArray, numbervalue, LL1, size);
        }

        if (value == 2) {

            return 0;
        }
        return 0;
    }//End of menuMethod

    public static void menuContents(ImageConstruction cons, ArrayList[][] bigArray, KeyboardInputClass numbervalue, LinkedList LL1, int size) {
        int circles = numbervalue.getInteger(true, 5, 1, 20, "Enter of the number of circles to create: ");
        entityX = new int[circles];
        entityY = new int[circles];
        velocityX = new int[circles];
        velocityY = new int[circles];
        radius = new int[circles];
        mass = new int[circles];
        distance = new int[circles];
        acceleration = new int[circles];
        gravitation = new int[circles];
        entityDifference = new int[circles];
        G = 2;

        int positionUI = numbervalue.getInteger(true, 3, 1, 3, "Enter how you want the position: [1] Random - [2] Grouped - [3] Specify");
        positionValue(LL1, cons, numbervalue, positionUI, circles);
        int radiusUI = numbervalue.getInteger(true, 5, 1, 20, "Enter how you want the radius: [1] Random - [2] Identical - [3] Specify");
        radianValue(cons, numbervalue, radiusUI, circles);
        zeroOut();

        DVT(bigArray, circles);
        //bigArray.equals(cons.redValues);
        gravityMethod(bigArray, circles);

        //LL1 = bigArraytoList(bigArray, LL1);
        //cons.displayImage(true, "old", true);
        //cons.closeDisplay();
        //cons = new ImageConstruction(width, height, 300, 700, 300, 700, 1);
        //cons.displayImage(true, "test", true);
        //cons = new ImageConstruction(cons.imageWidth = 1000, cons.imageHeight = 1000, 400, 600, 400, 600, 1);
        //cons.displayImage(true, "new", true);
        moveEntityPrompts(LL1, cons, numbervalue, bigArray, circles, size, positionUI);

        interactionMethod(bigArray);

    }//End of menuMethod method

    public static void radianValue(ImageConstruction cons, KeyboardInputClass numbervalue, int radiusUI, int circles) {
        if (radiusUI == 1) {
            Random ran = new Random();
            for (int i = 0; i < circles; i++) {
                radius[i] = ran.nextInt(entityX[i]);
                mass[i] = (int) Math.PI * (radius[i] * radius[i]);
                cons.insertCircle(entityX[i], entityY[i], radius[i] + 1, 0, 0, 0, true);
                cons.insertCircle(entityX[i], entityY[i], radius[i], 255, 0, 0, true);
            }// end of ui == 1 loop
        }// end of ui == 1 if
        if (radiusUI == 2) {
            Random ran = new Random();
            int identical = ran.nextInt(width) + 1;
            for (int i = 0; i < circles; i++) {
                radius[i] = identical / 8;
                mass[i] = (int) Math.PI * (radius[i] * radius[i]);
                cons.insertCircle(entityX[i], entityY[i], radius[i] + 1, 0, 0, 0, true);
                cons.insertCircle(entityX[i], entityY[i], radius[i], 255, 0, 0, true);
            }// end of ui == 2 loop
        }// end of ui == 2 if
        if (radiusUI == 3) {
            for (int i = 0; i < circles; i++) {
                radius[i] = numbervalue.getInteger(true, width / 8, 1, width - 1, "Enter radius for entity: ");
                mass[i] = (int) Math.PI * (radius[i] * radius[i]);
                cons.insertCircle(entityX[i], entityY[i], radius[i] + 1, 0, 0, 0, true);
                cons.insertCircle(entityX[i], entityY[i], radius[i], 255, 0, 0, true);
            }// end of ui == 3 loop
        }// end of ui == 3 if
    }//End of radianValue method

    public static int positionValue(LinkedList LL1, ImageConstruction cons, KeyboardInputClass numbervalue, int positionUI, int circles) {
        for (int i = 0; i < circles; i++) {

            if (positionUI == 1) {
                Random ran = new Random();
                //System.out.println(entityX[i] = ran.nextInt());
                entityX[i] = ran.nextInt(width) + 1;
                entityY[i] = ran.nextInt(height) + 1;
            }
            if (positionUI == 2) {
                double slice = 2 * Math.PI / circles;
                double angle = slice * i;
                entityX[i] = (int) (200 + 100 * Math.sin(angle));
                entityY[i] = (int) (200 + 100 * Math.cos(angle));
            }
            if (positionUI == 3) {
                entityX[i] = numbervalue.getInteger(true, width / 8, 1, width, "Enter x coordinate for entity: ");
                entityY[i] = numbervalue.getInteger(true, width / 8, 1, width, "Enter y coordinate for entity: ");
            }

        }// end of for loop
        return 0;
    }

    public static void moveEntityFunction(ArrayList[][] bigArray, int moveUI_1, int moveUI_2, ImageConstruction cons, KeyboardInputClass numbervalue, int circles) {
        cons.insertCircle(entityX[moveUI_1], entityY[moveUI_1], radius[moveUI_1], 0, 0, 0, true);
        ArrayList[][] al = new ArrayList[width][height];
        int pos1 = entityX[moveUI_1];
        int pos2 = entityY[moveUI_1];
        bigArray.equals(cons.redValues);
        cons.insertCircle(entityX[moveUI_1] + moveUI_2, entityY[moveUI_1] + moveUI_2, radius[moveUI_1], 255, 0, 0, true);
        cons.displayImage(true, "new image", true);

        for (int i = 1; i < 2; i++) {

            String menuUI = numbervalue.getString("ZO", "Iterate:\n     Press [0] to iterate by one:\nZoom:"
                    + "\n     Press [ZO] to zoom out:"
                    + "\n     Press [ZI] to zoom in:"
                    + "\nPan:"
                    + "\n     Press [PU] to pan up:"
                    + "\n     Press [PD] to pan down:"
                    + "\n     Press [PL] to pan left:"
                    + "\n     Press [PR] to pan right:"
                    + "\nTime:"
                    + "\n     Press [TD] to double time increment:"
                    + "\n     Press [TH] to half time increment:"
                    + "\nMisc:"
                    + "\n     Press [C] to change:"
                    + "\n     Press [R] to restart:"
                    + "\n     Press [E] to exit:\n ");

            //Zoom
            if ("I".equals(menuUI)) {
                interactionMethod(bigArray);
            }
            if ("ZO".equals(menuUI)) {

                cons.closeDisplay();
                //width += 100;
                //height += 100;
                //pRight += -50;
                //pTop += -50;
                bigArray.equals(cons.redValues);
                bigArray = Arrays.copyOf(bigArray, bigArray.length + 100);
                cons.redValues.equals(bigArray);
                cons.imageWidth += 100;
                cons.imageHeight += 100;
                cons.xRight += -50;
                cons.yTop += -50;
                if (cons.scaleFactor != 1) {
                    cons.scaleFactor += -1;
                }

                int value = 2;
                i = 0;

                menuMethod(width, height, circles, value, bigArray);
                cons.displayImage(true, "Zoom Out", true);
                //cons.closeDisplay();
            }
            if ("ZI".equals(menuUI)) {
                cons.closeDisplay();
                width += -100;
                height += -100;
                cons.yTop += 50;
                cons.yBottom += -50;
                cons.scaleFactor += 1;
                bigArray.equals(cons.redValues);
                bigArray = Arrays.copyOf(bigArray, bigArray.length + 100);
                int value = 2;
                i = 0;

                menuMethod(width, height, circles, value, bigArray);
                cons.displayImage(true, "Zoom In", true);

            }

            //Pan
            if ("PU".equals(menuUI)) {

                //cons.closeDisplay();
                //pLeft = 1;
                //pRight = 100;
                //bigArray.equals(cons.redValues);
                testarray = cons.redValues;
                for (int j = 0; j < bigArray.length; j++) {
                    for (int k = 0; k < bigArray.length; k++) {
                        bigArray[j][k].add(cons.redValues[j][k]);
                        testarray[j][k] = cons.redValues[j][k];
                    }
                    //System.out.println();
                }
                pTop += -100;
                pBottom += -100;

                //cons = new ImageConstruction(width, height, 1, pRight + 100, 1, pTop + 100, 1);
                //cons.displayImage(true, "new1", true);
                bigArray = Arrays.copyOf(bigArray, bigArray.length + 100);
                int value = 2;
                i = 0;
                int width2 = 700;
                int height2 = 700;
                ImageConstruction img = new ImageConstruction(width2, height2, pLeft, pRight, pBottom, pTop, 1
                );
                //menuMethod(width, height, circles, value, bigArray);
                
                for (int j = 0; j < img.redValues.length; j++) {
                    for (int k = 0; k < img.redValues.length; k++) {
                        String temp;
                        temp = bigArray[j][k].get(0).toString();
                        int temp2 = Integer.parseInt(temp);
                        img.redValues[j][k] = temp2;
                        //System.out.print(img.redValues[j][k]);
                    }
                    //System.out.println();
                
                }
                img.displayImage(true, "Pan Up", true);

            }
            if ("PD".equals(menuUI)) {
                cons.displayImage(true, "Pan Down", true);
                break;
            }
            if ("PL".equals(menuUI)) {
                cons.displayImage(true, "Pan Left", true);
                break;
            }
            if ("PR".equals(menuUI)) {
                cons.displayImage(true, "Pan Right", true);
                break;
            }

            //Time
            if ("TD".equals(menuUI)) {
                cons.displayImage(true, "Double Time Increment", true);
                break;
            }
            if ("TH".equals(menuUI)) {
                cons.displayImage(true, "Half Time Increment", true);
                break;
            }

            //Misc
            if ("C".equals(menuUI)) {
                cons.displayImage(true, "Change", true);
                break;
            }
            if ("R".equals(menuUI)) {
                cons.displayImage(true, "Restart", true);
                break;
            }
            if ("E".equals(menuUI)) {
                System.exit(0);
            }
            //cons.closeDisplay();
            //cons.displayImage(true, "1", true);

        }// end of adjustment if
    }//End of moveEntity method

    public static void moveEntityPrompts(LinkedList LL1, ImageConstruction cons, KeyboardInputClass numbervalue, ArrayList[][] bigArray, int circles, int size, int positionUI) {

        cons.displayImage(true, "windowTitle", true);
        int movePrompt = numbervalue.getInteger(true, 1, 1, 2, "Press [1] to start moving entities or [2] to quit.");
        for (int i = 0; i < 2; i++) {
            if (movePrompt == 1) {
                cons.closeDisplay();
                moveUI_1 = numbervalue.getInteger(true, 1, 1, circles, "Which entity would you like to move? ");
                moveUI_2 = numbervalue.getInteger(true, 10, -size, size, "How many spots would you like to move it?");
                moveEntityFunction(bigArray, moveUI_1, moveUI_2, cons, numbervalue, circles);
                int movePrompt2 = numbervalue.getInteger(true, 1, 1, 2, "Press [1] to keep moving entities or [2] to exit the program.");
                if (movePrompt2 == 1) {
                    i = 0;
                }//end of repeat if
            }// end of first movePrompt if
            if (movePrompt == 2) {
                System.exit(0);
            }// end of exit program if
        }// end of for loop
    }//End of moveEntityPrompts Method

    public static void DVT(ArrayList[][] bigArray, int circles) {
        for (int i = 0; i < circles; i++) {
            distance[i] = (int) (2 * Math.PI) * radius[i];
            velocityY[i] = distance[i] / (int) time;
            acceleration[i] = (velocityY[i] - temp) / (int) time;
            velocityX[i] = velocityY[i];

            temp = velocityX[i];
        }// end of DVT loop
    }//End of DVT method

    public static void gravityMethod(ArrayList[][] bigArray, int circles) {

        for (int i = 0; i < entityX.length; i++) {
            x1 = entityX[i];
            y1 = entityY[i];
            for (int j = 0; j < entityY.length; j++) {
                if (x1 != entityX[j] && y1 != entityY[j]) {
                    x2 = entityX[j];
                    y2 = entityY[j];
                }// end of x2y2 if            
                int distance = (int) Math.sqrt((x1 - x2) * (x1 - x2) + (y1 - y2) * (y1 - y2));
                System.out.println("Distance: " + distance);
                gravitation[i] = (G * (mass[i]) / distance);
                System.out.println("gravitation: " + gravitation[i]);
                System.out.println();
            }// end of j loop

        }// end of i loop
    }//End of gravityMethod

    public static LinkedList bigArraytoList(ArrayList[][] bigArray, LinkedList LL1) {
        for (int i = 0; i < height; i++) {
            for (int j = 0; j < width; j++) {
                LL1.add(bigArray[i][j]);
            }// end of first j loop
            LL1.add(300);
        }// end of first i loop

        for (int i = 0; i < LL1.size(); i++) {
            //  System.out.println(LL1.);
            //System.out.print(LL1.get(i));
            if (LL1.get(i).equals(300)) {
                //System.out.println();
            }// end of second j loop
        }// end of second i loop
        return LL1;
    }//End of bigArraytoList Method

    public static void interactionMethod(ArrayList[][] bigArray) {

        velocityX[time + 1] = velocityX[time] + acceleration[velocityX[time]] * time;
        velocityY[time + 1] = velocityY[time] + acceleration[velocityY[time]] * time;
        time++;
        for (int i = 0; i < entityX.length; i++) {
            distance[i] = (velocityX[i] * time) + ((1 / 2) * acceleration[i] * (time * time));
            distance[i] = (velocityY[i] * time) + ((1 / 2) * acceleration[i] * (time * time));
            acceleration[i] = gravitation[i] * mass[i] / entityDifference[i] * entityDifference[i];
        }
    }

    public static void zeroOut() {
        for (int i = 0; i < velocityX.length; i++) {
            velocityX[i] = 0;
            velocityY[i] = 0;
        }
    }
}//End of class
